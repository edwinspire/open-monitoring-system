<?php

ini_set('display_errors', 1);
require_once '/usr/share/php/Net/CheckIP.php';
//header('Content-type: application/xml');
// This file is automatically modified by usms not modify it. //
// To change these parameters do-it in the configuration file uhttp.conf //
//$conn_string = "host=localhost port=5432 dbname=farmaenlace user=postgres password=pg4321";
$conn_string = "host=localhost port=5432 dbname=farmaenlace user=postgres password=pg1234";
//$pGdbconn = pg_connect($conn_string)  or die("Could not connect");
?>
