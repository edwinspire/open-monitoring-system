define(
"dojox/widget/nls/th/ColorPicker", ({
redLabel: "r",
greenLabel: "ก.",
blueLabel: "b",
hueLabel: "ชม.",
saturationLabel: "วิ.",
valueLabel: "v", /* aka intensity or brightness */
degLabel: "\u00B0",
hexLabel: "hex",
huePickerTitle: "ตัวเลือกสี",
saturationPickerTitle: "ตัวเลือกความอิ่มของสี"
})
);
