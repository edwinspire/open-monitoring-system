//>>built
define("dojox/editor/plugins/nls/da/TextColor",{setButtonText:"Defin\u00e9r",cancelButtonText:"Annull\u00e9r"});
//# sourceMappingURL=TextColor.js.map