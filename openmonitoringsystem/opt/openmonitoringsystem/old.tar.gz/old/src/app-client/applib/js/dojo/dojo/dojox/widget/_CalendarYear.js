//>>built
define("dojox/widget/_CalendarYear",["dojo/_base/declare","./_CalendarYearView"],function(a,b){return a("dojox.widget._CalendarYear",null,{parent:null,constructor:function(){this._addView(b)}})});
//# sourceMappingURL=_CalendarYear.js.map