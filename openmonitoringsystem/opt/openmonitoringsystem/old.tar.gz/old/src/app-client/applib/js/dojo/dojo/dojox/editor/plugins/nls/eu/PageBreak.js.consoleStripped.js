define("dojox/editor/plugins/nls/eu/PageBreak", {      
//begin v1.x content
	"pageBreak": "Orrialde-jauzia"
//end v1.x content
});

