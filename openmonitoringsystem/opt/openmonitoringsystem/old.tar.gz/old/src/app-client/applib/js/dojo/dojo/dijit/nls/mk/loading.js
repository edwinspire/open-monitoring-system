//>>built
define("dijit/nls/mk/loading",{loadingState:"\u0412\u0447\u0438\u0442\u0443\u0432\u0430\u045a\u0435...",errorState:"\u0421\u0435 \u043f\u043e\u0458\u0430\u0432\u0438 \u0433\u0440\u0435\u0448\u043a\u0430"});
//# sourceMappingURL=loading.js.map