define(
"dojox/editor/plugins/nls/ru/TextColor", ({
	"setButtonText": "Задать",
	"cancelButtonText": "Отмена"
})
);
