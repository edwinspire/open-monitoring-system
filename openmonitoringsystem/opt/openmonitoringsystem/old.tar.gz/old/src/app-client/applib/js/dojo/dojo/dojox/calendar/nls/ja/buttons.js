//>>built
define("dojox/calendar/nls/ja/buttons",{previousButton:"\u25c4",nextButton:"\u25ba",todayButton:"\u4eca\u65e5",dayButton:"\u65e5",weekButton:"\u9031",fourDaysButton:"4 \u65e5\u9593",monthButton:"\u6708"});
//# sourceMappingURL=buttons.js.map