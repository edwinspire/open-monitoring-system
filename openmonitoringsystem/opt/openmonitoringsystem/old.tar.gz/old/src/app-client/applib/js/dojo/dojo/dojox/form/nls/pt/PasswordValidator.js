//>>built
define("dojox/form/nls/pt/PasswordValidator",{nomatchMessage:"As senhas n\u00e3o correspondem.",badPasswordMessage:"Senha Inv\u00e1lida."});
//# sourceMappingURL=PasswordValidator.js.map