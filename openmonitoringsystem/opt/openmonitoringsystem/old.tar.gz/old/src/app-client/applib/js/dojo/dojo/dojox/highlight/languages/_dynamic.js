//>>built
define("dojox/highlight/languages/_dynamic",["./python","./xquery","./groovy"],function(){});
//# sourceMappingURL=_dynamic.js.map