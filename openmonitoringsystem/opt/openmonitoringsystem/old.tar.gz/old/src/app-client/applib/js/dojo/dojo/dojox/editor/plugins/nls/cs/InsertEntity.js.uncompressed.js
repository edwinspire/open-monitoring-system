define(
"dojox/editor/plugins/nls/cs/InsertEntity", ({
	insertEntity: "Vložit symbol"
})
);
