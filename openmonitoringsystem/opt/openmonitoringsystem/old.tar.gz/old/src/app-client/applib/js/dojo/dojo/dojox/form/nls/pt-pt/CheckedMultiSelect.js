//>>built
define("dojox/form/nls/pt-pt/CheckedMultiSelect",{invalidMessage:"\u00c9 necess\u00e1rio seleccionar pelo menos um artigo.",multiSelectLabelText:"{num} artigo(s) seleccionado(s)"});
//# sourceMappingURL=CheckedMultiSelect.js.map