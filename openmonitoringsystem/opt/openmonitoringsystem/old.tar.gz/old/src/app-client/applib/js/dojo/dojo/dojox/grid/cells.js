//>>built
define("dojox/grid/cells",["../main","./cells/_base"],function(a){return a.grid.cells});
//# sourceMappingURL=cells.js.map