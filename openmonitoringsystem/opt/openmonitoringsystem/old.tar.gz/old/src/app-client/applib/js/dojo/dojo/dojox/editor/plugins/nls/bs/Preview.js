//>>built
define("dojox/editor/plugins/nls/bs/Preview",{preview:"Pregled"});
//# sourceMappingURL=Preview.js.map