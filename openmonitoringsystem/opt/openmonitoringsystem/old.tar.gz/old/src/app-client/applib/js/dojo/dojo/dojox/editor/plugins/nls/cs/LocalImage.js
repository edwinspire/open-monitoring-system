//>>built
define("dojox/editor/plugins/nls/cs/LocalImage",{insertImageTitle:"Vlo\u017eit obr\u00e1zek",url:"Obr\u00e1zek",browse:"Proch\u00e1zet...",text:"Popis",set:"Vlo\u017eit",invalidMessage:"Neplatn\u00fd typ souboru obr\u00e1zku",prePopuTextUrl:"Zadejte adresu URL obr\u00e1zku",prePopuTextBrowse:" nebo vyhledejte lok\u00e1ln\u00ed soubor."});
//# sourceMappingURL=LocalImage.js.map