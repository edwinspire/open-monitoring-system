//>>built
define("dojox/editor/plugins/nls/ro/Save",{save:"Salvare"});
//# sourceMappingURL=Save.js.map