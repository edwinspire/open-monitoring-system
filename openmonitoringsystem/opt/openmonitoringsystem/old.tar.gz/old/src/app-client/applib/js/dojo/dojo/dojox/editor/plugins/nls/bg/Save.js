//>>built
define("dojox/editor/plugins/nls/bg/Save",{save:"\u0417\u0430\u043f\u0430\u0437\u0438"});
//# sourceMappingURL=Save.js.map