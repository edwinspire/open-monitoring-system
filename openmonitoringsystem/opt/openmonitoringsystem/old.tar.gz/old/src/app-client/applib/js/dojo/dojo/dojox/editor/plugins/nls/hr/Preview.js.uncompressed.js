define(
"dojox/editor/plugins/nls/hr/Preview", ({
	"preview": "Pregled"
})
);
