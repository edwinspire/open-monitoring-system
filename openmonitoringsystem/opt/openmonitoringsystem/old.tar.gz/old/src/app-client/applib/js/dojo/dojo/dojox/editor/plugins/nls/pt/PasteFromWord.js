//>>built
define("dojox/editor/plugins/nls/pt/PasteFromWord",{pasteFromWord:"Colar do Word",instructions:"Cole o conte\u00fado do Word na caixa de texto a seguir. Quando estiver satisfeito com o conte\u00fado a ser inserido, pressione o bot\u00e3o para colar. Para interromper a inser\u00e7\u00e3o de texto, pressione o bot\u00e3o para cancelar."});
//# sourceMappingURL=PasteFromWord.js.map