define(
"dojox/editor/plugins/nls/fi/TextColor", ({
	"setButtonText": "Aseta",
	"cancelButtonText": "Peruuta"
})
);
