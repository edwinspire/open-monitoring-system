define(
"dojox/editor/plugins/nls/nb/Breadcrumb", ({
	"nodeActions": "${nodeName} Handlinger",
	"selectContents": "Velg innhold",
	"selectElement": "Velg element",
	"deleteElement": "Slett element",
	"deleteContents": "Slett innhold",
	"moveStart": "Flytt markør til start",
	"moveEnd": "Flytt markør til slutt"
})
);
