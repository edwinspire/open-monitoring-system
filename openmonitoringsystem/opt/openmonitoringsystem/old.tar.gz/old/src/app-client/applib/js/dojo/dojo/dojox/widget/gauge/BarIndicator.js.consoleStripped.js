// wrapped by build app
define("dojox/widget/gauge/BarIndicator", ["dojo","dijit","dojox","dojo/require!dojox/gauges/BarIndicator"], function(dojo,dijit,dojox){
dojo.provide('dojox.widget.gauge.BarIndicator');
dojo.require('dojox.gauges.BarIndicator');

dojox.widget.gauge.BarIndicator = dojox.gauges.BarIndicator;

});
