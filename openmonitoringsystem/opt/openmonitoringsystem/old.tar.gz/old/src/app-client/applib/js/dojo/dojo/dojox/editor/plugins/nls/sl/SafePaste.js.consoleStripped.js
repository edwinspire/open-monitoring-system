define(
"dojox/editor/plugins/nls/sl/SafePaste", ({
	"instructions": "Neposredno lepljenje je onemogočeno. Vsebino prilepite v to pogovorno okno s standardno tipkovnico brskalnika ali kontrolniki menija za lepljenje. Ko ste zadovoljni z vsebino, ki jo želite vstaviti, pritisnite gumb za lepljenje. Če želite preklicati vstavljanje vsebine, pritisnite gumb za preklic."
})
);
