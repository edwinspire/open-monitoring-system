//>>built
define("dojox/editor/plugins/nls/sl/Save",{save:"Shrani"});
//# sourceMappingURL=Save.js.map