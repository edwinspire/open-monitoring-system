define(
"dojox/editor/plugins/nls/th/InsertAnchor", ({
	insertAnchor: "แทรกจุดยึด",
	title: "คุณสมบัติจุดยึด",
	anchor: "ชื่อ:",
	text: "คำอธิบาย:",
	set: "เซ็ต",
	cancel: "ยกเลิก"
})
);
