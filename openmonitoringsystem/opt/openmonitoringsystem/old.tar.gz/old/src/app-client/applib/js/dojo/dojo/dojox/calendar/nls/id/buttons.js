//>>built
define("dojox/calendar/nls/id/buttons",{previousButton:"\u25c4",nextButton:"\u25ba",todayButton:"Hari Ini",dayButton:"Hari",weekButton:"Minggu",fourDaysButton:"4 Hari",monthButton:"Bulan"});
//# sourceMappingURL=buttons.js.map