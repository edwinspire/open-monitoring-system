define("dojox/mobile/nls/th/messages", {      
//begin v1.x content
	// Title of the previous button in Carousel
	"CarouselPrevious": "ก่อนหน้านี้",
	// Title of the next button in Carousel
	"CarouselNext": "ถัดไป",
	// PageIndicatorLabel: accessibility label for PageIndicator
	// $0 replaced by the index of the current page
	// $1 replaced by the total number of pages
	"PageIndicatorLabel": "หน้า $0 จาก $1"
//end v1.x content
});

