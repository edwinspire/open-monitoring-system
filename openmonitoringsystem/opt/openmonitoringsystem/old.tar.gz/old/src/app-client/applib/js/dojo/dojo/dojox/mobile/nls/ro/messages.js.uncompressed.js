define("dojox/mobile/nls/ro/messages", {      
//begin v1.x content
	// Title of the previous button in Carousel
	"CarouselPrevious": "Anterioară",
	// Title of the next button in Carousel
	"CarouselNext": "Următoare",
	// PageIndicatorLabel: accessibility label for PageIndicator
	// $0 replaced by the index of the current page
	// $1 replaced by the total number of pages
	"PageIndicatorLabel": "pagina $0 din $1"
//end v1.x content
});

