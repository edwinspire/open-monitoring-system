define(
"dojox/atom/widget/nls/nl/PeopleEditor", ({
	add: "Toevoegen",
	addAuthor: "Auteur toevoegen",
	addContributor: "Deelnemer toevoegen"
})
);
