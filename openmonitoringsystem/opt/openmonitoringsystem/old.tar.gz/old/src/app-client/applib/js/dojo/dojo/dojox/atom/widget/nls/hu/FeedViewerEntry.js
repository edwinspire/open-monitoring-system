//>>built
define("dojox/atom/widget/nls/hu/FeedViewerEntry",{deleteButton:"[T\u00f6rl\u00e9s]"});
//# sourceMappingURL=FeedViewerEntry.js.map