define("dojox/editor/plugins/nls/sr/BidiSupport", {      
//begin v1.x content
	"ltr": "Smer teksta sa leva na desno",
	"rtl": "Smer teksta sa desna na levo"
//end v1.x content
});

