//>>built
define("dojox/charting/themes/RoyalPurples",["../SimpleTheme","./common"],function(b,a){a.RoyalPurples=new b({colors:["#473980","#685aa7","#7970b3","#231c3f","#7267ae"]});return a.RoyalPurples});
//# sourceMappingURL=RoyalPurples.js.map