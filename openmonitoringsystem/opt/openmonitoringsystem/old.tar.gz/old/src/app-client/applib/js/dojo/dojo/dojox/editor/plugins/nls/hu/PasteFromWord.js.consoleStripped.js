define(
"dojox/editor/plugins/nls/hu/PasteFromWord", ({
	"pasteFromWord": "Beillesztés Word alkalmazásból",
	"instructions": "Illessze be a Word alkalmazás tartalmát az alábbi szövegmezőbe. Ha elégedett a beszúrandó tartalommal, akkor nyomja meg a beillesztés gombot. Szöveg beszúrásának megszakításához nyomja meg a mégse gombot."
})
);
