//>>built
define("dojox/editor/plugins/nls/ca/TextColor",{setButtonText:"Defineix",cancelButtonText:"Cancel\u00b7la"});
//# sourceMappingURL=TextColor.js.map