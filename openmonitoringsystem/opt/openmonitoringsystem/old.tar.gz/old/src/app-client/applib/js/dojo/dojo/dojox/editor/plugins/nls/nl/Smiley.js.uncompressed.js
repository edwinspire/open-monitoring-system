define(
"dojox/editor/plugins/nls/nl/Smiley", ({
	smiley: "Emoticon invoegen",
	emoticonSmile: "glimlach",
	emoticonLaughing: "lach",
	emoticonWink: "knipoog",
	emoticonGrin: "grijns",
	emoticonCool: "cool",
	emoticonAngry: "kwaad",
	emoticonHalf: "half",
	emoticonEyebrow: "verbaasd",
	emoticonFrown: "frons",
	emoticonShy: "verlegen",
	emoticonGoofy: "goofy",
	emoticonOops: "oeps",
	emoticonTongue: "tong",
	emoticonIdea: "idee",
	emoticonYes: "ja",
	emoticonNo: "nee",
	emoticonAngel: "engel",
	emoticonCrying: "bedroefd",
	emoticonHappy: "blij"
})
);
