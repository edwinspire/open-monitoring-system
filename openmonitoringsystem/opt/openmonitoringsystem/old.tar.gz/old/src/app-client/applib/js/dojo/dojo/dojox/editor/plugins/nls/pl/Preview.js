//>>built
define("dojox/editor/plugins/nls/pl/Preview",{preview:"Podgl\u0105d"});
//# sourceMappingURL=Preview.js.map