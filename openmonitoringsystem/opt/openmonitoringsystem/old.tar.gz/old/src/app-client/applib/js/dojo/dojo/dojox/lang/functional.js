//>>built
define("dojox/lang/functional",["./functional/lambda","./functional/array","./functional/object"],function(a){return a});
//# sourceMappingURL=functional.js.map