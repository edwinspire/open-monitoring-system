//>>built
define("dojox/fx/easing",["dojo/_base/lang","dojo/_base/kernel","dojo/fx/easing"],function(a,b,c){b.deprecated("dojox.fx.easing","Upgraded to Core, use dojo.fx.easing instead","2.0");return a.getObject("dojox.fx",!0).easing=c});
//# sourceMappingURL=easing.js.map