define('dojox/grid/nls/DataGrid_en-us',{
'dijit/nls/loading':{"loadingState":"Loading...","errorState":"Sorry, an error occurred","_localized":{}}
});