//>>built
define("dojox/editor/plugins/nls/cs/Save",{save:"Ulo\u017eit"});
//# sourceMappingURL=Save.js.map