//>>built
define("dojox/editor/plugins/nls/bs/Breadcrumb",{nodeActions:"${nodeName} Akcije",selectContents:"Izbor sadr\u017eaja",selectElement:"Izbor elementa",deleteElement:"Bri\u0161i element",deleteContents:"Bri\u0161i sadr\u017eaj",moveStart:"Pomakni kursor na po\u010detak",moveEnd:"Pomakni kursor na kraj"});
//# sourceMappingURL=Breadcrumb.js.map