//>>built
define("dojox/calendar/nls/kk/buttons",{previousButton:"\u25c4",nextButton:"\u25ba",todayButton:"\u0411\u04af\u0433\u0456\u043d",dayButton:"\u041a\u04af\u043d",weekButton:"\u0410\u043f\u0442\u0430",fourDaysButton:"4 \u043a\u04af\u043d",monthButton:"\u0410\u0439"});
//# sourceMappingURL=buttons.js.map