//>>built
define("dojox/editor/plugins/nls/uk/Blockquote",{blockquote:"\u0411\u043b\u043e\u043a \u0446\u0438\u0442\u0430\u0442"});
//# sourceMappingURL=Blockquote.js.map