//>>built
define("dojox/editor/plugins/nls/nb/Blockquote",{blockquote:"Blokksitat"});
//# sourceMappingURL=Blockquote.js.map