//>>built
define("dojox/editor/plugins/nls/ja/ShowBlockNodes",{showBlockNodes:"HTML \u30d6\u30ed\u30c3\u30af\u8981\u7d20\u306e\u8868\u793a"});
//# sourceMappingURL=ShowBlockNodes.js.map