define(
"dojox/editor/plugins/nls/pt-pt/InsertAnchor", ({
	insertAnchor: "Inserir âncora",
	title: "Propriedades da âncora",
	anchor: "Nome:",
	text: "Descrição:",
	set: "Definir",
	cancel: "Cancelar"
})
);
