define(
"dojox/editor/plugins/nls/sv/InsertAnchor", ({
	insertAnchor: "Infoga ankare",
	title: "Ankaregenskaper",
	anchor: "Namn:",
	text: "Beskrivning:",
	set: "Använd",
	cancel: "Avbryt"
})
);
