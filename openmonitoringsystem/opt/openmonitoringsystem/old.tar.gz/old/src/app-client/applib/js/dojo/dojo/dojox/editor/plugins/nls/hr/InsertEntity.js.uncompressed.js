define(
"dojox/editor/plugins/nls/hr/InsertEntity", ({
	insertEntity: "Umetni simbol"
})
);
