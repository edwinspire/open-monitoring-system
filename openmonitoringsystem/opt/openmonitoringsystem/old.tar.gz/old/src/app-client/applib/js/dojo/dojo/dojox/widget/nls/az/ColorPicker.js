//>>built
define("dojox/widget/nls/az/ColorPicker",{redLabel:"q",valueLabel:"d",hexLabel:"onalt\u0131l\u0131q",hueLabel:"\u00e7",saturationLabel:"d",greenLabel:"y",blueLabel:"m",saturationPickerTitle:"Doldurmaq se\u00e7imi",huePickerTitle:"\u00c7alar se\u00e7imi",degLabel:"\u00b0"});
//# sourceMappingURL=ColorPicker.js.map