define(
"dojox/editor/plugins/nls/da/TextColor", ({
	"setButtonText": "Definér",
	"cancelButtonText": "Annullér"
})
);
