define(
"dojox/editor/plugins/nls/de/SafePaste", ({
	"instructions": "Direktes Einfügen ist inaktiviert. Fügen Sie Inhalt in diesem Dialog über Tastaturbefehle oder Menüeinträge für Einfügeoperationen Ihres Standardbrowsers ein. Wenn Sie mit dem einzufügenden Inhalt zufrieden sind, klicken Sie auf die Schaltfläche Einfügen. Wenn Sie das Einfügen des Inhalts abbrechen möchten, klicken Sie auf die Schaltfläche Abbrechen."
})
);
