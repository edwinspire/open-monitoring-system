define(
({
	singleSort: "Yksinkertainen lajittelu",
	nestedSort: "Sisäkkäinen lajittelu",
	ascending: "Lajittele nousevaan järjestykseen napsauttamalla",
	descending: "Lajittele laskevaan järjestykseen napsauttamalla",
	sortingState: "${0} - ${1}",
	unsorted: "Älä lajittele tätä saraketta",
	indirectSelectionRadio: "Rivi ${0}, yksi valinta, valintanappi",
	indirectSelectionCheckBox: "Rivi ${0}, useita valintoja, valintaruutu",
	selectAll: "Valitse kaikki"
})
);
