define(
({
	name: "Ime",
	path: "Staza",
	size: "Veličina (u bajtovima)"
})
);
