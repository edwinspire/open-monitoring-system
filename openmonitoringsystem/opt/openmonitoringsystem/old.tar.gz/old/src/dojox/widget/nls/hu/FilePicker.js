define(
({
	name: "Név",
	path: "Elérési út",
	size: "Méret (byte)"
})
);
