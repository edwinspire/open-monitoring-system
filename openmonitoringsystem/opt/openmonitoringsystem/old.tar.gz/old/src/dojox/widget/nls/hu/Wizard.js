define(
({
next: "Tovább",
previous: "Előző",
done: "Kész"
})
);
