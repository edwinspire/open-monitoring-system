define(
({
	insertAnchor: "Insereix una àncora",
	title: "Propietats de l'àncora",
	anchor: "Nom:",
	text: "Descripció:",
	set: "Defineix",
	cancel: "Cancel·la"
})
);
