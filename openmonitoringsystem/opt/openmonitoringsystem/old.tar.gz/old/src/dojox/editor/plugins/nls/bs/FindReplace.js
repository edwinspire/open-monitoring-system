define({      
//begin v1.x content
	"findLabel": "Nađi:",
	"findTooltip": "Unesite tekst koji treba naći",
	"replaceLabel": "Zamijeni sa:",
	"replaceTooltip": "Unesite tekst s kojim zamijeniti",
	"findReplace": "Nađi i zamijeni",
	"matchCase": "Spari slovo",
	"matchCaseTooltip": "Spari slovo",
	"backwards": "Unazad",
	"backwardsTooltip": "Pretražuj unazad za tekst",
	"replaceAllButton": "Zamijeni sve",
	"replaceAllButtonTooltip": "Zamijeni cijeli tekst",
	"findButton": "Nađi",
	"findButtonTooltip": "Nađi tekst",
	"replaceButton": "Zamijeni",
	"replaceButtonTooltip": "Zamijeni tekst",
	"replaceDialogText": "Zamijenjena ${0} pojavljivanja",
	"eofDialogText": "zadnje pojavljivanje ${0}",
	"eofDialogTextFind": "pronađeno",
	"eofDialogTextReplace": "zamijenjeno"
//end v1.x content
});

