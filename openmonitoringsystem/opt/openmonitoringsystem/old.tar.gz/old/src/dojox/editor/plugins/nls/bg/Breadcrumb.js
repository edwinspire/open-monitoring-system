define(
({
	"nodeActions": "${nodeName} Действия",
	"selectContents": "Избери съдържание",
	"selectElement": "Избери елемент",
	"deleteElement": "Изтрий елемент",
	"deleteContents": "Изтрий съдържание",
	"moveStart": "Премести курсора в началото",
	"moveEnd": "Премести курсора в края"
})
);
