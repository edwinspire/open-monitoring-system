define({      
//begin v1.x content
	"save": "Spremi"
//end v1.x content
});

