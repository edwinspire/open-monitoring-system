define(
({
	"save": "Desa"
})
);
