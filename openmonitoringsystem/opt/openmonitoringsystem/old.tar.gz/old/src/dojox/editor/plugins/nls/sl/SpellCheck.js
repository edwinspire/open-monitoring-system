define(
({
	widgetLabel: "Paketno preverjanje črkovanja ",
	unfound: "Ni najdeno ",
	skip: "Preskoči",
	skipAll: "Preskoči vse",
	toDic: "Dodaj v slovar ",
	suggestions: "Predlogi ",
	replace: "Zamenjaj ",
	replaceWith: "Zamenjaj z",
	replaceAll: "Zamenjaj vse",
	cancel: "Prekliči",
	msg: "Najdenih ni bilo nobenih napačnih črkovanj ",
	iSkip: "Preskoči to ",
	iSkipAll: "Preskoči vse vnose, kot je ta ",
	iMsg: "Ni predlogov za črkovanje "
})
);
