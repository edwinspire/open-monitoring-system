define(
({
	"collapse": "Spusti traku s alatima editora",
	"expand": "Proširi traku s alatima editora"
})
);
