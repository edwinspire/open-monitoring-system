define(
({
	widgetLabel: "Dávková kontrola pravopisu",
	unfound: "Nenašlo sa",
	skip: "Preskočiť",
	skipAll: "Preskočiť všetko",
	toDic: "Pridať do slovníka",
	suggestions: "Návrhy",
	replace: "Nahradiť",
	replaceWith: "Nahradiť s",
	replaceAll: "Nahradiť všetko",
	cancel: "Zrušiť",
	msg: "Nenašli sa žiadne chyby",
	iSkip: "Preskočiť toto",
	iSkipAll: "Preskočiť všetky podobné",
	iMsg: "Žiadne návrhy na hláskovanie"
})
);
