define(
({
	"pageBreak": "改ページ"
})
);
