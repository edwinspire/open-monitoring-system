define({      
//begin v1.x content
	"preview": "Pregled"
//end v1.x content
});

