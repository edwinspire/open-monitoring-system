define(
({
	"blockquote": "Blockquote"
})
);
