define(
({
	insertAnchor: "Вставить метку",
	title: "Свойства метки",
	anchor: "Имя:",
	text: "Описание:",
	set: "Задать",
	cancel: "Отмена"
})
);
