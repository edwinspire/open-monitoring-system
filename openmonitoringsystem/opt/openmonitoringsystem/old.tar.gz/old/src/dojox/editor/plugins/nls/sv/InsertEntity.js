define(
({
	insertEntity: "Infoga symbol"
})
);
