define({      
//begin v1.x content
	"setButtonText": "Postavi",
	"cancelButtonText": "Odustani"
//end v1.x content
});

