define(
({
	"setButtonText": "Nastavit",
	"cancelButtonText": "Storno"
})
);
