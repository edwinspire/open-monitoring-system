define(["doh/main", "require", "dojo/sniff"], function(doh, require, has){

	doh.registerUrl("dojox.mobile.tests.doh.TextBox", require.toUrl("./TextBoxTests.html"),999999);
});



