define({      
//begin v1.x content
	// Title of the previous button in Carousel
	"CarouselPrevious": "Προηγούμενο",
	// Title of the next button in Carousel
	"CarouselNext": "Επόμενο",
	// PageIndicatorLabel: accessibility label for PageIndicator
	// $0 replaced by the index of the current page
	// $1 replaced by the total number of pages
	"PageIndicatorLabel": "σελίδα $0 από $1"
//end v1.x content
});

