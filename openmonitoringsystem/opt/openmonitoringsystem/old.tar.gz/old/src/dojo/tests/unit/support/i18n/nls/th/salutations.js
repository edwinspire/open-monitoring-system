define(
//begin v1.x content
{
 th: "ქართული ენაქართული ენაქართული ენაสวัสดีครับ/คะ",
 hello: "ภาษาไทย"
}
//end v1.x content
);
