#!/bin/bash
/home/edwinspire/Documentos/Desarrollo/open-monitoring-system/node_modules/.bin/jsdoc /home/edwinspire/Documentos/Desarrollo/open-monitoring-system/src/app_client/js/dojo/custom -r -d /home/edwinspire/Documentos/Desarrollo/open-monitoring-system/docs/client
/home/edwinspire/Documentos/Desarrollo/open-monitoring-system/node_modules/.bin/jsdoc /home/edwinspire/Documentos/Desarrollo/open-monitoring-system/node_modules/dojo-node/node_modules/custom -r -d /home/edwinspire/Documentos/Desarrollo/open-monitoring-system/docs/server
