define(['dojo/_base/declare',
  'dijit/_Widget',
  'dijit/_Templated',
  'dojo/text!notification_area/notification_area.html',
  "dojo/dom-construct",
  "dojo/dom-style", 
  'dojo/request',
  'dojo/on',
  "dojo/topic",
  "socketio/socketio",
  "dojo/cookie"
  ], function (declare, _Widget, _Templated, templateString, domConstruct, domStyle, R, on, topic, io, cookie) {

    return declare([_Widget, _Templated], {
      widgetsInTemplate: true,
      _lastidnotify: 0,
      templateString: templateString,
      postCreate: function () {
        var t = this;



        var socket = io.connect('ws://'+document.location.host);

        socket.on('connection', function(client) {  
          console.log('Client connected...');
          socket.emit('heartbeat', {sessionidclient: cookie('oms_sessionidclient'), token: cookie('oms_sessiontoken')});
        });



        socket.on('notifying_the_user', function(data) {

          var item = JSON.parse(data);
                       //   console.log(item);
                       t.Notify({Message: item.body, Title: item.title, iconClass: item.iconClass, Snd: item.snd, Timeout: item.timeout, Urgency: item.urgency, Closable: item.closable});
                     });



        socket.on('pgtschange', function(data) {
          var tables = JSON.parse(data);
          if(tables && tables.table_name){                         
            var eventurl = "/event/table/changed/"+tables.table_name;                                               
            topic.publish(eventurl, [{table: tables.table_name}]);
          }

        });

        socket.on('command', function(data) {
          var command = data;
          console.log(command);
          switch(command.command){
            case 'logout':
          //  cookie("oms_sessionidclient", "anonymous", { expires: 5000 });
          //  cookie("oms_fullname", "anonymous", { expires: 5000 });
          window.location="/njs/logout";
          break; 
          case 'heartbeat':
          socket.emit('heartbeat', {sessionidclient: cookie('oms_sessionidclient')});
          break;             

        }

      });



        setInterval(function(){
		//socket.send(cookie('oms_sessionidclient')+'dfdsfdsf');
		socket.emit('heartbeat', {sessionidclient: cookie('oms_sessionidclient')});
	}, 30000);


        topic.subscribe("/event/notification_area/notify", function(data){
         t._Notify(data);
       });





      },
      _args: function (a) {
        if (a.Message === undefined || a.Message.length < 1) {
          a.Message = '';
        }

        if (a.Title === undefined || a.Title.length < 1) {
          a.Title = '';
        }



        if (a.IconClass === undefined || a.IconClass.length < 1) {
         a.IconClass = 'glyphicon-bell';
       }

		//a.iconClass = t._set_iconclass();

    a.Snd = 'js/dojo/custom/notification_area/notify.ogg';
/*
            if (a.Snd === undefined || a.Snd.length < 5) {
                a.Snd = 'lib/js/dojo/custom/NotificationArea/notify.ogg';
            }
            */

            if (a.Timeout === undefined || a.Timeout < 2) {
              a.Timeout = 10;
            }

            if (a.Urgency === undefined || a.Urgency < 1) {
              a.Urgency = 100;
            }

            return a;
          },

          _set_iconclass: function(iconclass, defaulticonclass){
            var icon = 'glyphicon-bell';
            if (iconclass === undefined || iconclass.length < 1) {
             icon = defaulticonclass;
           }else{
            icon = iconclass;
          }
          return icon;
        },       
        Notify: function(_args){
          topic.publish("/event/notification_area/notify", _args);
        }, 
        _Notify: function (args_) {

//console.log(args_);
var t = this;
var args = t._args(args_);

     //        bsc = 'NotificationArea';


if (true) {
//     if (!("Notification" in window)) {
      t._notify_browser_not_support(args);
    }

  // Let's check whether notification permissions have already been granted
  else if (Notification.permission === "granted") {
    // If it's okay let's create a notification
    t._notify_browser(args);
  }

  // Otherwise, we need to ask the user for permission
  else if (Notification.permission !== 'denied') {
    Notification.requestPermission(function (permission) {
      // If the user accepts, let's create a notification
      if (permission === "granted") {
        t._notify_browser(args);
      }
    });
  }else{
    t._notify_browser_not_support(args, bsc);
  }


},
NotifyRequestError: function(error){
  this.Notify({Title: error.status, Message: error});
},
_notify_browser: function(args){
  var n = new Notification(args.Title, {body: args.Message, sound: args.Snd});
  setTimeout(n.close.bind(n), args.Timeout * 1000); 
},
_notify_browser_not_support: function(args){

  var bsc = '';

  if (args.Urgency <= 2) {
              //  bsc = '#d80000';
              bsc = 'NotificationArea_12';
              
            } else if (args.Urgency <= 4) {
               // bsc = '#ff6100';
               bsc = 'NotificationArea_34';
               
             } else if (args.Urgency <= 6) {
               // bsc = '#ffc700';
               bsc = 'NotificationArea_56';
               
             } else if (args.Urgency <= 8) {
               // bsc = '#ffe100';
               bsc = 'NotificationArea_78';
               
             } else if (args.Urgency <= 10) {
               // bsc = '#ffe100';
               bsc = 'NotificationArea_910';
               
             } else {
               // bsc = '#8b9fb2';
               bsc = 'NotificationArea';
             }


             var node = domConstruct.create("span");

// Esta funcion hace que la notificacion se cierre al hacer click en ella.
if (args.Closable) {
  dojo.connect(node, "onclick", function () {
    domConstruct.destroy(this);
  });
}

node.innerHTML = ' <div class="'+ bsc +'"><span class="glyphicon '+args.IconClass+'" aria-hidden="true"></span><span class="notificacion_area_title">' + args.Title + '</span>  <div class="notificacion_area_message">' + args.Message + '</div> <audio src="' + args.Snd + '" autoplay></audio> </div>';


domConstruct.place(node, this.container, "first");
//console.log('to '+args.Timeout);
// Este bloque hace que pasado el Timeout la notificacion se cierre automaticamente
setTimeout(function () {
  domConstruct.destroy(node);
}, args.Timeout * 1000);


}




});
});
