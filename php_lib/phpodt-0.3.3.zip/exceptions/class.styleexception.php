<?php
//	include_once 'class.odtexception.php';

//include '../class.odt.php';
	
	class StyleException extends ODTException {
		
	}
?>
